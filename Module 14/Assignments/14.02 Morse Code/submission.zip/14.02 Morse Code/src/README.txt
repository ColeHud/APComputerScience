PROJECT TITLE: 14.02 Morse Code
PURPOSE OF PROJECT: Translate English to Morse Code using only static methods
VERSION or DATE: 3/1/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This assignment went by without a hitch. It was really rewarding getting the output and being able to plug it
into an online translator.
      
<-s>: Writing everything with static methods was really awkward for me. I've gotten used to doing everything using 
object oriented programming, and this was just out of my comfort zone.
           
*************************************************************************
I'm super excited for the assignments coming up in the future. I've found cryptography really interesting for quite some 
time. A few years ago, when my family visited a beach, I wrote a message encoded in a Caesar shift cipher in the sand to 
see if anyone would figure it out. Creating encoded messages is cool, but I'm even more excited to write programs that break
codes.