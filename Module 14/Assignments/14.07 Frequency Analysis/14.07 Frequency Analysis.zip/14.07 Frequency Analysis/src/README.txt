PROJECT TITLE: 14.07 Frequency Analysis
PURPOSE OF PROJECT: perform a frequency analysis of the letters in a message and use the results to decipher a secret message 
VERSION or DATE: 3/8/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This assignment went surprisingly well. At first I was terrified that the computer would be doing
all of the deciphering, but I was relieved to learn that we only had to write the frequency analyzer. After
I figured out how to map the characters to the frequencies, everything went well.
      
<-s>: As I mentioned in the questions/evaluation, I had some difficulty at first, mapping the frequencies to a data
structure. After a while I ended up using the HashMap.
           
*************************************************************************
The HashMap was a life-saver in this assignment. I'm definitely going to be using it a lot more in the future. I found
it super useful and easy to implement.