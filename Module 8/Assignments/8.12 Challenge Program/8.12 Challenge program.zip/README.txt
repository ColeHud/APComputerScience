PROJECT TITLE: 8.12 Challenge program	
PURPOSE OF PROJECT: Model an individual's CO2 production and reduction.
VERSION or DATE: 1/8/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This assignment was pretty easy because it built well off of the previous assignments.
I was able to reuse some of my code from previous assignments for some calculations. 
      
<-s>: There wasn't really anything that went wrong when writing this program. After making the class diagram
and pseudocode everything moved on from there.
           
*************************************************************************
I really liked how this assignment built off of the previous assignments because it provided a good review
of everything covered in the chapter. I'm really starting to appreciate the power of pseudocode; it helped 
me a lot in this assignment to get all of my ideas out really quickly. In the future I'm DEFINITELY going to 
use more pseudocode.