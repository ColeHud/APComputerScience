PROJECT TITLE: 8.09 Javadoc
PURPOSE OF PROJECT: Calculate the amount of carbon dioxide emitted for each gallon of gas consumed.
VERSION or DATE: 1/4/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: The assignment instructions were really straightforward and provided some useful guides such as the class
diagram. From that point on I had an easy time writing this program.
      
<-s>: At first I made getter methods, but then I thought that I wouldn't need them, so I deleted the methods. 
Later on I had to come back and redo them. 
           
*************************************************************************
This probably isn't a bad thing, but I like adding a lot of functionality to my constructors, but the rubric 
always tells me to place the methods in the main function. This seems like it would work just fine, but by placing
the methods in the constructor it allows for more scalability. 

These javadocs are hard to get used to, but they're incredibly useful. It's kind of painful while writing them, but
it will definitely help me out when I come back to look at my programs in the future.


P.S. My values are a little bit different from the expected output because I used Google's ton-to-pound number which
is a tad bit different from the example in the assignment instructions.