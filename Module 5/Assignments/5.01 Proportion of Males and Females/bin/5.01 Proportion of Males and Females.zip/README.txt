PROJECT TITLE: 5.01 Male to Female Population Ratios
PURPOSE OF PROJECT: Simulate the male to female ratio of a country of your choice
VERSION or DATE: 10/21/2014
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This went really well for me, I experimented a TON with the coin flip program. To fill out the
worksheet I actually wrote a program almost exactly like this one which I was then able to use a lot 
of to create this program.
      
<-s>: While programming I became unfocused and lost track of what I was supposed to be doing. I started
writing and changing programs to solve problems for the worksheet that weren't that important, rather
than quickly getting through the worksheet so that I could work on this assignment.
           
*************************************************************************
In the future I need to work on being more focused and on task while programming. It's really easy to
"Feature creep" and add unnecessary trouble to what you're working on.