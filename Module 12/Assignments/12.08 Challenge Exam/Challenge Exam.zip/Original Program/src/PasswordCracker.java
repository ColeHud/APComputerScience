import java.util.Arrays;

/*
 * By Cole Hudson
 * Date: 2/15/2015
 * 
 * Purpose: Crack a "Password" using brute force recursive power
 */
public class PasswordCracker 
{
	//variables
	private int length;
	private int[] password;
	private int[] crackedPass;
	private boolean foundPassword = false;
	
	//constructor
	PasswordCracker(int[] passwordArray)
	{
		password = passwordArray;
		length = password.length;
		crackedPass = new int[length];
		crackPassword(0);
	}
	
	
	//recursive password cracker
	public void crackPassword(int index)
	{
		//if the array has been fully iterated through
		if(index >= length)
		{
			//if the password is correct
			if(Arrays.equals(password, crackedPass))
			{
				System.out.println("We cracked it!");
				
				//print the password
				for(int digit: crackedPass)
				{
					System.out.print(digit);
				}
				return;
			}
		}
		else
		{
			//go through each possible number
			for(int i = 0; i <= 9; i++)
			{
				//simplify each digit down into it's own problem, then solve
				crackedPass[index] = i;
				crackPassword(index + 1);
			}
		}
		
		
	}	
}
