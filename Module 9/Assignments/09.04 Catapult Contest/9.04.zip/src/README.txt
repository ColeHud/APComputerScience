PROJECT TITLE: Catapult-A-Cantaloupe (9.04)
PURPOSE OF PROJECT: Calculate the trajectory of projectiles based on launch angles and velocities.
VERSION or DATE: 1/22/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This program had it's ups and downs, but there were a few things that went really well.
My original algorithm for initializing and calculating the arrays was spot on, which felt really good.
I first thought through how the program was going to work, and from there I was able to write a skeleton
for the program which helped me out a lot.
      
<-s>: I ran into some trouble with the Math.sin() function because of my degrees-radians conversion. Even though
I was converting from degrees to radians, something wasn't working. After a while I was able to resolve the issue.
           
*************************************************************************
One of my favorite things about this program is how versatile it is. I specifically made it so you could tweak almost
everything; the start values, iterator, number of values, etc. In the future I will try to continue adding in 
enhancements like this. Overall I enjoyed this program and found it very rewarding at the end to see this giant 
table of values sitting in front of me.