PROJECT TITLE: eimacs Lab 4
PURPOSE OF PROJECT: Create a model of a warehouse that receives footwear
VERSION or DATE: 3/1/2015
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This is exactly the assignment that I've been waiting for! It was a lot of fun getting to finally implement the class
hierarchy things that we've learned about. I had a few minor hiccups, but other than that, this project went really well. 
I especially liked creating the receive() method where I got to implement some recursion to make the task simpler. I think my
recursion might have even been more efficient than the sample code!
      
<-s>: I struggled with the warehouse toString() method for a few hours yesterday. I was having trouble using the lookup method
and combining it with the normal toString() from the bin.
           
*************************************************************************
I loved this assignment. Even though it was a little bit longer, I felt like I learned a lot from it. I especially appreciated
how the assignment helped us along the way, rather than just giving us starting instructions, then cutting us loose. In the
future I hope that we have more assignments similar to this. If I did this again I wouldn't change anything.

P.S. Sorry for the zip archive :)