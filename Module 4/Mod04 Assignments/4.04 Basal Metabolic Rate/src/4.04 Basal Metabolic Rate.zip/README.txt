PROJECT TITLE: 4.04 Basal Metabolic Rate
PURPOSE OF PROJECT: Calculate your heart basal metabolic rate.
VERSION or DATE: 10/12/2014
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: At first I was really scared by that large equation, but once I broke it down everything went really well. I struggled with removing the decimal
places for a while, but then I wrote it down on paper and came up with the steps I needed. From there it was a breeze.
      
<-s>: I forgot that I needed the boolean variable, so I had to go back and add it back in instead of directly evaluating it in the conditional.
           
*************************************************************************
I found that writing my problem down and figuring it out on paper was really helpful. In the future I will definitely try doing that again.