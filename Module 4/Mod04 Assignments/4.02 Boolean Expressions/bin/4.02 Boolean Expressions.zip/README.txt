PROJECT TITLE: 4.02 Boolean Expressions
PURPOSE OF PROJECT: The purpose of this program is to evaluate whether the nutritional components listed on a food label exceed the Daily Reference value for a healthy diet.
VERSION or DATE: 10/10/2014
AUTHORS: C.Hudson

Test the program with the following values
	Calories 2000
	Fat 65 grams 
	Cabohydrates 300 grams 
	Fiber 25 grams 
	Protein 50 grams

***************************   PMR  **************************************
 
<+s>: After reading through the assignment instructions and the program given, typing everything else up was pretty easy given the predefined structure of the program.
I tried changing the percentages to type Double for precision, but it really messed up the formatting so I switched it back.
      
<-s>: I made a few errors copying and pasting blocks of code around the program that probably could have been avoided. Due to the similarity of the variable
names I had some errors concerning those as well.
           
*************************************************************************
This program went really well! I tried programming with 2 monitors today and it was really cool. I have the IDE with which I am typing this on my large monitor,
and then I keep the Java console/output on my laptop's screen, as well as the instructions and lessons. I am definitely going to continue using this system
when programming at home, it's really efficient. I also switched Eclipse's preferences so that it is in "Dark" mode which reminds me a lot of Sublime text;
an editor that I use a lot. It looks really cool, and it helps me read my code a lot better. I'll include a screenshot of my workspace (the smaller side of the
screenshot is my laptop).