PROJECT TITLE: 4.05 Body Mass Index
PURPOSE OF PROJECT: Calculate a person's Body Mass Index
VERSION or DATE: 10/12/2014
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This program was really similar to a lot of the previous programs which made it simple to structure it. It was nice being able to reuse the code that
I used to get rid of the decimal places. 
      
<-s>: I don't really have many negatives for this project. Like all programs, I probably could have commented it better, but I didn't really have any trouble 
with this. My variable names could have been a bit more consistent and less obscure;
           
*************************************************************************
In the future I would like all assignments to go this well! 