PROJECT TITLE: Heart Rate Target Zone
PURPOSE OF PROJECT: Calculate heart rate and target zone
VERSION or DATE: 10/11/2014
AUTHORS: C.Hudson

***************************   PMR  **************************************
 
<+s>: This program was pretty straightforward. The equations had already been figured out and the picture of what the output is supposed to look like
is already given. From there it was pretty simple to write the code for the heart rate equations and to get the input from the user.
      
<-s>: I forgot that we had to declare string variables so I had to go back for each input and add in the string declarations. I also had some trouble
with adding in the different text depending on the boolean value, until I realized that I had couldn't declare the variable in the if statement, but
that I had to declare it outside of the statement, and then change its value in the if statement.
           
*************************************************************************
In the future I should pay more attention to the rubric before I make my program, rather than going through it afterward as a checklist (though I should
do that too).